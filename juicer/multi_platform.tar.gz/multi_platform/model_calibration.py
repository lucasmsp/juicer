# coding=utf-8

import pymysql.cursors
import pymysql
import json
import os
import time
import re

import numpy as np
import requests
import json
import yaml
import sys

import networkx as nx
from networkx.drawing.nx_agraph import graphviz_layout
import matplotlib.pyplot as plt
import itertools
import pandas as pd
import datetime
import gettext
import traceback
import pickle

from juicer.multi_platform.auxiliar_services import *
from juicer.multi_platform.jobs_api import LemonadeJob, HistoricalLemonadeJob
from juicer.multi_platform.auxiliar_services import get_sql_connection

DEBUG = True


def log(msg):
    if DEBUG:
        print(msg)


class CostModel(object):

    def __init__(self, current_job_id=None, last_job_id=None):
        self.lemonade_jobs = []

        # Connect to the database
        self.connection = get_sql_connection()

        self.actions_ids = get_action_ids(self.connection)
        self.operation_slugs = get_slug_operations(self.connection)

        if not current_job_id:
            current_job_id = 0
        self.current_job_id = current_job_id

        if not last_job_id:
            last_job_id = get_last_job(self.connection)
        self.last_job_id = last_job_id

        config = "/opt/workspace/bigsea/docker-lemonade/config/juicer-config-local.yaml"
        juicer_config = {}
        with open(config) as config_file:
            juicer_config = yaml.load(config_file.read(), Loader=yaml.FullLoader)
        juicer_config['juicer']['services']['tahiti']["url"] = "http://localhost:23403"

        locales_path = os.path.join(os.path.dirname(__file__), 'i18n', 'locales')
        t = gettext.translation('messages', locales_path, ["en"], fallback=True)
        t.install()
        self.juicer_config = juicer_config
        self.models = {}

    def data_gathering(self):

        log(f"Starting from job: {self.current_job_id}")
        log(f"Last Job: {self.last_job_id}")

        while self.current_job_id <= self.last_job_id:

            current_job = get_job(self.connection, self.current_job_id)
            #log(f">> JOB_id {current_job_id}")

            if current_job:
                if current_job["status"] == "COMPLETED":
                    current_job_log = get_job_log(self.connection, self.current_job_id)
                    if len(current_job_log) > 0:
                        not_completed = any(status != "COMPLETED"
                                            for status in [step["s_status"] for step in current_job_log])
                        if not not_completed:
                            current_job_log = pd.DataFrame.from_dict(current_job_log)

                            current_job_log_start = current_job_log.loc[(current_job_log["l_status"] == "RUNNING") |
                                                                        (current_job_log["l_status"] == "PENDING")]\
                                .copy()
                            current_job_log_start.loc[:, 'l_status'] = 'RUNNING'
                            current_job_log_start = current_job_log_start\
                                .groupby(["task_id", "l_status", "operation_id", "date"])\
                                .agg(l_date=("l_date", min)) \
                                .reset_index() \
                                .to_dict('records')
                            current_job_log_end = current_job_log.loc[current_job_log["l_status"] == "COMPLETED"] \
                                .groupby(["task_id", "l_status", "operation_id", "date"]) \
                                .agg(l_date=("l_date", max)) \
                                .reset_index() \
                                .to_dict('records')

                            if len(current_job_log_start) <= len(current_job_log_end):
                                current_job_log = current_job_log_start + current_job_log_end

                                hlj = None
                                try:
                                    hlj = HistoricalLemonadeJob(current_job, current_job_log, self.actions_ids,
                                                                self.juicer_config, self.operation_slugs)
                                    self.lemonade_jobs.append(hlj)
                                except Exception as e:
                                    print(f"[ERROR] JOB_id {self.current_job_id}")
                                    print(str(e))
                                    if "Operation does not exist anymore" not in str(e):
                                        print(hlj.jobs)
                                        print(hlj.plot())
                                        traceback.print_exc()
                                        exit(1)
                            else:
                                print("[WARN] Skipping JOB_ID {} - Nº steps COMPLETED is different from RUNNING."
                                      .format(self.current_job_id))
                                print(current_job_log_start)
                                print("---------------")
                                print(current_job_log_end)
                                print("\n\n\n\n")
                                exit(1)
                            # log("Created at {}".format(lj.created_timestamp))
                            # log("Started at {}".format(lj.started_timestamp))
                            # log("Finished at {}".format(lj.finished_timestamp))
                            #log(">>> COMPLETE DAG")
                            #lj.plot()
                            # print("This workflow took {} seconds to start".format(lj.seconds_to_start))
                            # print(">>> JOBS:", lj.jobs)

            self.current_job_id += 1

    def gen_dataflow_model_v1(self, lj=None):
        if lj:
            dataflow = lj.get_dataflow("v1")
        else:
            dataflow = [d for lj in self.lemonade_jobs for d in lj.get_dataflow("v1")]

        dataflow = pd.DataFrame(dataflow)
        cols_op = ["op_{}".format(i + 1) for i in range(100)]
        dataflow.columns = ["lemonade_id", "total_seconds", "platform_id", "input_size"] + cols_op
        dataflow[cols_op] = dataflow[cols_op].replace({0.0: None})
        return dataflow

    def gen_dataflow_model_v2(self, lj=None):
        if lj:
            dataflow = lj.get_dataflow("v2")
            slugs = lj.slugs_operation
            dims = lj.dim_per_operation

            print("gen_dataflow_model_v2: ", lj.jobs)
            print("gen_dataflow_model_v2: ", dataflow)
        else:
            dataflow = [d for lj in self.lemonade_jobs for d in lj.get_dataflow("v2")]
            slugs = self.lemonade_jobs[0].slugs_operation
            dims = self.lemonade_jobs[0].dim_per_operation

        dataflow = [list(itertools.chain.from_iterable(d)) for d in dataflow]
        dataflow = pd.DataFrame(dataflow)
        print(dataflow)
        cols = ["{}_{}".format(s, d) for s in slugs for d in range(dims[s])]
        dataflow.columns = ["lemonade_id", "total_seconds", "platform_id", "input_size"] + cols
        return dataflow

    def gen_dataflow_model_v3(self, lj=None):
        if lj:
            dataflow = lj.get_dataflow("v3")
            # slugs = sorted(list(lj.operation_api.all_operations.keys()))
            # dims = lj.dim_per_operation

            print("gen_dataflow_model_v3: ", lj.jobs)
            print("gen_dataflow_model_v3: ", dataflow)
        else:
            tmp = [d for lj in self.lemonade_jobs for d in lj.get_dataflow("v3")]
            slugs_fields = self.lemonade_jobs[0].operation_api.get_all_dimensions_dict()
            dataflow = []
            rows = []
            for r in tmp:
                row = slugs_fields.copy()
                for op in r[4]:
                    for f in r[4][op]:
                        row["{}_{}".format(op, f)] = r[4][op][f]
                rows.append(row)
                dataflow.append([r[0], r[1], r[2], r[3]])

            rows = pd.DataFrame.from_dict(rows)
            dataflow = pd.DataFrame(dataflow)
            dataflow.columns = ["lemonade_id", "total_seconds", "platform_id", "input_size"]
            dataflow = pd.merge(dataflow, rows, how='inner', left_index=True, right_index=True)

        return dataflow

    def load_models(self):
        filename = "/home/lucasmsp/workspace/doutorado/thesis/models.pickle"
        self.models = pickle.load(open(filename, 'rb'))

    def save_database(self):
        filename = "/home/lucasmsp/workspace/doutorado/thesis/database.pickle"
        with open(filename, 'wb') as handle:
            pickle.dump(self.lemonade_jobs, handle)

    def load_database(self):
        filename = "/home/lucasmsp/workspace/doutorado/thesis/database.pickle"
        self.lemonade_jobs = pickle.load(open(filename, 'rb'))

    def extract_jobs(self, workflow):
        lj = LemonadeJob(workflow, self.actions_ids, self.juicer_config, self.operation_slugs)
        return lj

    def where_to_run(self, rows):
        self.load_models()
        table = [{} for _ in range(len(rows))]
        for m in self.models:
            mm = self.models[m]
            for i, r in enumerate(rows):
                table[i][m] = mm.predict([r])

        result = {"predictions": table}
        duration = 0
        flow = []

        for t in table:
            spark = t["Spark"]
            pandas = t["Pandas"]
            if spark > pandas:
                flow.append("Pandas")
                duration += pandas[0]
            else:
                flow.append("Spark")
                duration += spark[0]

        result["flow"] = flow
        result["duration"] = duration
        print("where_to_run: ", result)
        return result

    #def __del__(self):
     #   self.connection.close()

#def main():
#    return CostModel()

#if __name__ == "__main__":
#    main()
