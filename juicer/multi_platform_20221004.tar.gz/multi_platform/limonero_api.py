# coding=utf-8

import pymysql.cursors
import pymysql
import json
import os
import time
import re
import pdb
import numpy as np
import requests
import json
import yaml
import sys
from collections import OrderedDict
import networkx as nx
from networkx.drawing.nx_agraph import graphviz_layout
import matplotlib.pyplot as plt
import itertools
import pandas as pd
import datetime
from gettext import gettext
from juicer.multi_platform.auxiliar_services import get_sql_connection

# LIBRARY_PATH = os.path.expanduser("/home/lucasmsp/workspace/bigsea/docker-lemonade/juicer/")
# sys.path.insert(0, LIBRARY_PATH)
# os.environ["PYTHONPATH"] = os.environ.get("PYTHONPATH", "") + ":" + LIBRARY_PATH

import findspark
findspark.init()

from juicer.spark.data_operation import DataReaderOperation
from pyspark.sql import types
from pyspark.sql.functions import col, countDistinct
from pyspark.sql import SparkSession

from juicer.multi_platform.auxiliar_services import LIMONERO_DB


class Dataset(object):

    def __init__(self, base_id):
        self.size = 0.00
        self.storage_name = None
        self.format = None
        self.storage_type = None
        self.url = None
        self.storage_id = None
        self.name = None
        self.base_id = base_id
        self.get_base_stats()

    def get_base_stats(self):
        connection = get_sql_connection(LIMONERO_DB)
        with connection.cursor() as cursor:
            sql = """
            SELECT ds.id, ds.name, ds.url, format, estimated_size_in_mega_bytes, 
                   storage_id,  s.name AS storage_name, s.type AS storage_type 
            FROM {LIMONERO_DB}.data_source ds
            INNER JOIN {LIMONERO_DB}.storage s ON s.id = ds.storage_id
            WHERE ds.id = {BASE_ID};
            """.format(LIMONERO_DB=LIMONERO_DB, BASE_ID=self.base_id)
            cursor.execute(sql)
            result = cursor.fetchone()
        connection.commit()
        connection.close()

        self.name = result['name']
        self.url = result['url']
        self.format = result['format']
        try:
            self.size = float(result.get("estimated_size_in_mega_bytes", -1))
        except:
            self.size = -1
        if self.size == 0.00:
            self.size = 0.01
        self.storage_id = result['storage_id']
        self.storage_name = result['storage_name']
        self.storage_type = result['storage_type']

    def print_stats(self):
        print(f"""
        Name: {self.name}
        url: {self.url}
        format: {self.format}
        size: {self.size}
        storage_name: {self.storage_name}
        storage_type: {self.storage_type}
        """)


def remove_initial_final_path_separator(path):
    if path.endswith('/'):
        path = path[:-1]
    if path.startswith('/'):
        path = path[1:]
    return path


def query_limonero(base_url, item_path, token, item_id):
    headers = {'X-Auth-Token': token}
    base_url = remove_initial_final_path_separator(base_url)
    item_path = remove_initial_final_path_separator(item_path)
    item_id = remove_initial_final_path_separator(str(item_id))

    if base_url.endswith('/'):
        base_url = base_url[:-1]

    if item_path.endswith('/'):
        item_path = item_path[:-1]

    if item_path:
        url = '{}/{}/{}'.format(base_url, item_path, item_id)
    else:
        url = '{}/{}'.format(base_url, item_id)

    # log.debug(gettext('Querying Limonero URL: %s'), url)

    r = requests.get(url, headers=headers)
    if r.status_code == 200:
        return json.loads(r.text)
    else:
        log.error(gettext('Error querying Limonero URL: %s (%s: %s)'), url,
                  r.status_code, r.text)
        if r.status_code == 404:
            msg = gettext("not found")
        else:
            msg = r.text
        raise ValueError(gettext(
            "Error loading {} id {}: HTTP {} - {} ({})").format(
            item_path, item_id, r.status_code, msg, url))


class DataSources(object):

    def __init__(self):

        self.last_datasource_id = None
        self.current_datasource_id = 1
        self.load_id()

    def save_id(self, datasource_id):
        with open("/tmp/limonero_info.txt", "w") as f:
            f.write(f"{datasource_id}")

    def load_id(self):
        if os.path.exists("/tmp/limonero_info.txt"):
            with open("/tmp/limonero_info.txt", "r") as f:
                self.current_datasource_id = float(f.read())

    def get_last_datasource_id(self):
        connection = get_sql_connection(LIMONERO_DB)
        with connection.cursor() as cursor:
            sql = f"SELECT MAX(id) as id from {LIMONERO_DB}.data_source"
            cursor.execute(sql)
            result = cursor.fetchone()['id']
        connection.commit()
        connection.close()
        self.last_datasource_id = result
        return result

    def check_datasource_id(self, data_source_id):
        connection = get_sql_connection(LIMONERO_DB)
        with connection.cursor() as cursor:
            sql = f"SELECT id as id from {LIMONERO_DB}.data_source WHERE id = {data_source_id}"
            cursor.execute(sql)
            result = cursor.fetchone()
        connection.commit()
        connection.close()
        has_id = True if result else False
        return has_id

    def update_limonero(self, sqls):
        connection = get_sql_connection(LIMONERO_DB)
        for sql in sqls:
            with connection.cursor() as cursor:
                cursor.execute(sql)
                cursor.fetchall()
            connection.commit()
            connection.close()

    def calibrate(self):

        juicer_config = yaml.load(
            open("/home/lucasmsp/workspace/bigsea/docker-lemonade/config/juicer-config-local.yaml").read(),
            Loader=yaml.FullLoader)

        app_configs = juicer_config['juicer']['spark']
        spark_builder = SparkSession.builder.appName('Helper')
        for option, value in app_configs.items():
            spark_builder = spark_builder.config(option, value)
        spark_session = spark_builder.getOrCreate()

        datasources = [i for i in range(self.current_datasource_id, self.last_datasource_id)]
        stats = {}
        for datasource_id in datasources:
            print(f"Checking datasource {datasource_id} ...")
            if not self.check_datasource_id(datasource_id):
                print(f"Datasource {datasource_id} does not exist.")
                continue

            try:
                parameters = {
                    "data_source": datasource_id,
                    "mode": "PERMISSIVE",
                    'configuration': {
                        'juicer': {
                            'services': {
                                'limonero': {
                                    'url': 'http://localhost:23402',
                                    'auth_token': '123456'
                                }
                            }
                        }
                    },
                    'workflow': {'data_source_cache': {}}
                }
                n_out = {'output data': 'df'}
                data_reader = DataReaderOperation(parameters, named_inputs={}, named_outputs=n_out)
                code = data_reader.generate_code()
                code = code[:code.rfind('\n')]
                exec(code)
                estimated_rows = df.count()
                stats[datasource_id] = {"estimated_rows": estimated_rows, "attribute": {}}
                distinct_values = df.agg(*(countDistinct(col(c)).alias(c) for c in df.columns)) \
                    .toPandas() \
                    .to_dict(orient="records")[0]

                summary = df.summary().toPandas().set_index("summary").T.to_dict(orient='index')
                for c in df.columns:
                    if summary[c]['mean'] not in [None, "NaN", "Infinity"]:
                        mean = float(summary[c]['mean'])
                        if mean >= 2e30:
                            mean = "NULL"
                    else:
                        mean = "NULL"

                    if summary[c]['stddev'] not in ["NaN", None]:
                        std_deviation = float(summary[c]['stddev'])
                        if std_deviation >= 2e30:
                            std_deviation = "NULL"
                    else:
                        std_deviation = "NULL"
                    min_value = summary[c]['min']
                    max_value = summary[c]['max']
                    median = summary[c]['50%'] if summary[c]['50%'] else 'NULL'

                    stats[datasource_id]['attribute'][c] = {'distinct_values': distinct_values[c],
                                                            'missing_total': estimated_rows - int(summary[c]['count']),
                                                            'mean': mean,
                                                            'min': min_value,
                                                            'max': max_value,
                                                            'std_deviation': std_deviation,
                                                            'median': median}
            except:
                print(f"Unable to read datasource {datasource_id}")

            sqls = ["UPDATE {}.data_source SET estimated_rows={} WHERE id = {}"
                    .format(LIMONERO_DB, stats[row]['estimated_rows'], row) for row in stats]
            self.update_limonero(sqls)

            sqls = ["""
            UPDATE {LIMONERO_DB}.attribute 
            SET min_value='{min_value}', max_value='{max_value}', mean_value={mean_value}, std_deviation={std_deviation},
                median_value={median_value}, distinct_values={distinct_values}, missing_total={missing_total} 
            WHERE name='{name}' AND data_source_id = {data_source_id} 
            """.format(LIMONERO_DB=LIMONERO_DB, min_value=stats[ds]['attribute'][att]["min"],
                       max_value=stats[ds]['attribute'][att]["max"],
                       mean_value=stats[ds]['attribute'][att]["mean"],
                       median_value=stats[ds]['attribute'][att]["median"],
                       std_deviation=stats[ds]['attribute'][att]["std_deviation"],
                       distinct_values=stats[ds]['attribute'][att]["distinct_values"],
                       missing_total=stats[ds]['attribute'][att]["missing_total"],
                       name=att, data_source_id=ds) for ds in stats for att in stats[ds]["attribute"]]

            self.update_limonero(sqls)
            self.save_id(self.last_datasource_id)
            spark_session.stop()


if __name__ == "__main__":
    ds = DataSources()
    ds.get_last_datasource_id()
    print("Current ID: {} | Last ID: {}".format(ds.current_datasource_id, ds.last_datasource_id))

    if ds.last_datasource_id != ds.current_datasource_id:
        print("Limonero info must be calibrated ...")
        ds.calibrate()
    print("Limonero's calibration is finished ...")
